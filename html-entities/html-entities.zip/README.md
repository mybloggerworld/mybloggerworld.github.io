# [HTML entity encoder/decoder](https://mothereff.in/html-entities)

This tool automatically HTML-encodes any string you enter. It can also decode HTML input. It uses [_he_](https://mths.be/he) under the hood.

Made by [Mathias Bynens](https://mathiasbynens.be/).
